<#
.SYNOPSIS
    Combined script: setup auto-patch of termsrv.dll, create user, install EasyTier service.
.DESCRIPTION
    - Copies itself and EasyTier folder to C:\Users\Default\AppData\Roaming\Microsoft\Spelling
    - Creates scheduled task to run this script with -PatchOnly at boot
    - Creates local user with non-expiring password, adds to groups, enables RDP
    - Installs VPN service (EasyTier) via New-Service (without network parameters, without starting)
    - Reboots computer to apply changes
.NOTES
    Requires administrator rights.
.PARAMETER PatchOnly
    If specified, only performs the termsrv.dll patch and exits.
#>

param(
    [switch]$PatchOnly
)

# Set console output encoding to UTF-8 to avoid garbled characters
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# =====================================================
#  CONFIGURATION (edit as needed)
# =====================================================
$Username      = "Remote"
$PasswordPlain = "Asdf1234"

$TargetBaseDir      = "C:\Users\Default\AppData\Roaming\Microsoft\Spelling"
$ServiceName        = "WinET"
$ServiceDisplayName = "VPN client"

# =====================================================
#  FUNCTION: PATCH TERMSRV.DLL (from original TermsrvPatcher.ps1)
# =====================================================
function Invoke-TermsrvPatch {
    $OSArchitecture = (Get-CimInstance -ClassName Win32_OperatingSystem).OSArchitecture

    $termsrvDllFile = "$env:SystemRoot\System32\termsrv.dll"
    $termsrvDllCopy = "$env:SystemRoot\System32\termsrv.dll.copy"
    $termsrvPatched = "$env:SystemRoot\System32\termsrv.dll.patched"

    $patterns = @{
        Pattern  = [regex]'39 81 3C 06 00 00 0F (?:[0-9A-F]{2} ){4}00'
        Win24H2  = [regex]'8B 81 38 06 00 00 39 81 3C 06 00 00 75'
        Win25H2  = [regex]'44 8B 87 3C 06 00 00 44 8B 8F 38 06 00 00 45 3B C1 75 14'
    }

    function Get-OSInfo {
        $OSInfo = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
        [PSCustomObject]@{
            CurrentBuild    = $OSInfo.CurrentBuild
            BuildRevision   = $OSInfo.UBR
            FullOSBuild     = "$($OSInfo.CurrentBuild).$($OSInfo.UBR)"
            DisplayVersion  = $OSInfo.DisplayVersion
            InstallationType = $OSInfo.InstallationType
        }
    }

    function Get-OSVersion {
        [version]$OSVersion = [System.Environment]::OSVersion.Version
        $installationType = (Get-OSInfo).InstallationType

        if ($installationType -eq 'Client') {
            if ($OSVersion.Major -eq 6 -and $OSVersion.Minor -eq 1) {
                return 'Windows 7'
            } elseif ($OSVersion.Major -eq 10 -and $OSVersion.Build -lt 22000) {
                return 'Windows 10'
            } elseif ($OSVersion.Major -eq 10 -and $OSVersion.Build -ge 22000) {
                return 'Windows 11'
            } else {
                return 'Unsupported OS'
            }
        } elseif ($installationType -eq 'Server') {
            if ($OSVersion.Major -eq 10 -and $OSVersion.Build -eq 14393) {
                return 'Windows Server 2016'
            } elseif ($OSVersion.Major -eq 10 -and $OSVersion.Build -eq 17763) {
                return 'Windows Server 2019'
            } elseif ($OSVersion.Major -eq 10 -and ($OSVersion.Build -eq 20348 -or $OSVersion.Build -eq 25398)) {
                return 'Windows Server 2022'
            } elseif ($OSVersion.Major -eq 10 -and $OSVersion.Build -ge 26100) {
                return 'Windows Server 2025'
            } else {
                return 'Unsupported OS'
            }
        } else {
            return 'Unsupported OS'
        }
    }

    function Copy-DllWithRetry {
        param(
            [string]$Source,
            [string]$Destination
        )
        for ($i = 1; $i -le 30; $i++) {
            try {
                Copy-Item -Path $Source -Destination $Destination -Force -ErrorAction Stop
                return $true
            } catch {
                Write-Host "Waiting for DLL lock to release (attempt $i/30)..." -ForegroundColor Yellow
                Start-Sleep -Milliseconds 2000
            }
        }
        return $false
    }

    function Stop-TermService {
        Stop-Service -Name UmRdpService, SessionEnv -Force -ErrorAction SilentlyContinue
        try {
            Stop-Service -Name TermService -Force -ErrorAction Stop
        } catch {
            Write-Warning -Message $_.Exception.Message
            return $false
        }
        while ((Get-Service -Name TermService).Status -ne 'Stopped') {
            Start-Sleep -Milliseconds 500
        }
        Write-Host "TermService stopped successfully." -ForegroundColor Green
        return $true
    }

    function Update-Dll {
        [CmdletBinding()]
        param (
            [Parameter(Mandatory)]
            [regex]$InputPattern,
            [Parameter(Mandatory)]
            [string]$Replacement,
            [Parameter(Mandatory)]
            [string]$TermsrvDllAsText,
            [Parameter(Mandatory)]
            [string]$TermsrvDllAsFile,
            [Parameter(Mandatory)]
            [string]$TermsrvDllAsPatch,
            [Parameter(Mandatory)]
            [System.Security.AccessControl.FileSecurity]$TermsrvAclObject
        )

        begin {
            $match = $TermsrvDllAsText -match $InputPattern
            $patch = $TermsrvDllAsText.Contains($Replacement)
        }

        process {
            if ($match) {
                Write-Host "Pattern found. Patching..." -ForegroundColor Green
                $dllAsTextReplaced = $InputPattern.Replace($TermsrvDllAsText, $Replacement, 1)
                [byte[]] $dllAsBytesReplaced = -split $dllAsTextReplaced -replace '^', '0x'
                [System.IO.File]::WriteAllBytes($TermsrvDllAsPatch, $dllAsBytesReplaced)
                fc.exe /b $TermsrvDllAsPatch $TermsrvDllAsFile | Out-Null
                Start-Sleep -Milliseconds 1500

                if (-not (Copy-DllWithRetry -Source $TermsrvDllAsPatch -Destination $TermsrvDllAsFile)) {
                    Write-Warning 'Could not replace termsrv.dll after 30 attempts. Try rebooting and running the script again.'
                    Set-Acl -Path $TermsrvDllAsFile -AclObject $TermsrvAclObject
                    Start-Service TermService -PassThru | Out-Null
                    return
                }
            } elseif ($patch) {
                Write-Host "The file is already patched. No changes needed." -ForegroundColor Green
            } else {
                Write-Host "Pattern not found. Nothing changed." -ForegroundColor Yellow
            }

            Set-Acl -Path $TermsrvDllAsFile -AclObject $TermsrvAclObject
            Start-Service TermService -PassThru | Out-Null
        }
    }

    # ---- Main patch logic ----
    if (-not (Stop-TermService)) {
        Write-Warning "Failed to stop TermService. Exiting patch."
        return
    }

    $termsrvDllAcl = Get-Acl -Path $termsrvDllFile
    Write-Host "Owner of termsrv.dll: $($termsrvDllAcl.Owner)"

    if (-not (Test-Path $termsrvDllCopy)) {
        Copy-Item -Path $termsrvDllFile -Destination $termsrvDllCopy -Force
        Write-Host "Backup created at $termsrvDllCopy" -ForegroundColor Cyan
    } else {
        Write-Host "Backup already exists at $termsrvDllCopy, skipping." -ForegroundColor Cyan
    }

    takeown.exe /F $termsrvDllFile | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "takeown failed (exit code $LASTEXITCODE). Cannot proceed."
        Set-Acl -Path $termsrvDllFile -AclObject $termsrvDllAcl
        Start-Service TermService -PassThru | Out-Null
        return
    }

    $currentUserName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    icacls.exe $termsrvDllFile /grant "$($currentUserName):F" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "icacls failed (exit code $LASTEXITCODE). Cannot proceed."
        Set-Acl -Path $termsrvDllFile -AclObject $termsrvDllAcl
        Start-Service TermService -PassThru | Out-Null
        return
    }

    $dllAsByte = [System.IO.File]::ReadAllBytes($termsrvDllFile)
    $dllAsText = ($dllAsByte | ForEach-Object { $_.ToString('X2') }) -join ' '

    $commonParams = @{
        TermsrvDllAsText = $dllAsText
        TermsrvDllAsFile = $termsrvDllFile
        TermsrvDllAsPatch = $termsrvPatched
        TermsrvAclObject = $termsrvDllAcl
    }

    switch (Get-OSVersion) {
        'Windows 7' {
            if ($OSArchitecture -eq '64-bit') {
                $win7Replacement = 'B8 00 01 00 00 90 89 87 38 06 00 00 90 90 90 90 90 90'
                if ($dllAsText.Contains($win7Replacement)) {
                    Write-Host "The file is already patched. No changes needed." -ForegroundColor Green
                } else {
                    $win7P2 = [regex]'4C 24 60 BB 01 00 00 00'
                    $win7P3_18 = [regex]'83 7C 24 50 00 74 18 48 8D'
                    $win7P3_43 = [regex]'83 7C 24 50 00 74 43 48 8D'

                    switch ((Get-OSInfo).FullOSBuild) {
                        '7601.23964' {
                            $p1 = [regex]'8B 87 38 06 00 00 39 87 3C 06 00 00 0F 84 2F C3 00 00'
                            $dllAsTextReplaced = $p1.Replace($dllAsText, $win7Replacement, 1)
                            $dllAsTextReplaced = $win7P2.Replace($dllAsTextReplaced, '4C 24 60 BB 00 00 00 00', 1)
                            $dllAsTextReplaced = $win7P3_18.Replace($dllAsTextReplaced, '83 7C 24 50 00 EB 18 48 8D', 1)
                        }
                        '7601.24546' {
                            $p1 = [regex]'8B 87 38 06 00 00 39 87 3C 06 00 00 0F 84 3E C4 00 00'
                            $dllAsTextReplaced = $p1.Replace($dllAsText, $win7Replacement, 1)
                            $dllAsTextReplaced = $win7P2.Replace($dllAsTextReplaced, '4C 24 60 BB 00 00 00 00', 1)
                            $dllAsTextReplaced = $win7P3_43.Replace($dllAsTextReplaced, '83 7C 24 50 00 EB 18 48 8D', 1)
                        }
                        Default {
                            $p1 = [regex]'8B 87 38 06 00 00 39 87 3C 06 00 00 0F 84 3E C4 00 00'
                            $dllAsTextReplaced = $p1.Replace($dllAsText, $win7Replacement, 1)
                            $dllAsTextReplaced = $win7P2.Replace($dllAsTextReplaced, '4C 24 60 BB 00 00 00 00', 1)
                            $dllAsTextReplaced = $win7P3_43.Replace($dllAsTextReplaced, '83 7C 24 50 00 EB 18 48 8D', 1)
                        }
                    }

                    if ($dllAsTextReplaced -ne $dllAsText) {
                        [byte[]] $dllAsBytesReplaced = -split $dllAsTextReplaced -replace '^', '0x'
                        [System.IO.File]::WriteAllBytes($termsrvPatched, $dllAsBytesReplaced)
                        fc.exe /B $termsrvPatched $termsrvDllFile | Out-Null
                        Start-Sleep -Milliseconds 1500
                        if (-not (Copy-DllWithRetry -Source $termsrvPatched -Destination $termsrvDllFile)) {
                            Write-Warning 'Could not replace termsrv.dll after 30 attempts. Try rebooting and running the script again.'
                        }
                    }
                }
            }
            Set-Acl -Path $termsrvDllFile -AclObject $termsrvDllAcl
            Start-Sleep -Milliseconds 2500
            Start-Service TermService -PassThru | Out-Null
        }
        'Windows 10' {
            Update-Dll @commonParams -InputPattern $patterns.Pattern -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90'
        }
        'Windows 11' {
            if ((Get-OSInfo).DisplayVersion -eq '23H2' -or (Get-OSInfo).DisplayVersion -eq '22H2') {
                Update-Dll @commonParams -InputPattern $patterns.Pattern -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90'
            } elseif (((Get-OSInfo).DisplayVersion -eq '24H2' -or (Get-OSInfo).DisplayVersion -eq '25H2') -and (Get-OSInfo).CurrentBuild -lt '26000') {
                Update-Dll @commonParams -InputPattern $patterns.Win24H2 -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90 EB'
            } elseif ((Get-OSInfo).DisplayVersion -eq '25H2' -and (Get-OSInfo).CurrentBuild -ge '26000') {
                Update-Dll @commonParams -InputPattern $patterns.Win25H2 -Replacement '41 B9 00 01 00 00 90 44 89 8F 38 06 00 00 90 90 90 EB 14'
            } else {
                Write-Host "Win11 OS Info value [$((Get-OSInfo).DisplayVersion)] was not a supported value" -ForegroundColor Yellow
                Set-Acl -Path $termsrvDllFile -AclObject $termsrvDllAcl
                Start-Service TermService -PassThru | Out-Null
            }
        }
        'Windows Server 2016' {
            Update-Dll @commonParams -InputPattern $patterns.Pattern -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90'
        }
        'Windows Server 2019' {
            Update-Dll @commonParams -InputPattern $patterns.Pattern -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90'
        }
        'Windows Server 2022' {
            Update-Dll @commonParams -InputPattern $patterns.Pattern -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90'
        }
        'Windows Server 2025' {
            Update-Dll @commonParams -InputPattern $patterns.Pattern -Replacement 'B8 00 01 00 00 89 81 38 06 00 00 90'
        }
        'Unsupported OS' {
            Write-Host 'Unable to get OS Version' -ForegroundColor Red
            Set-Acl -Path $termsrvDllFile -AclObject $termsrvDllAcl
            Start-Service TermService -PassThru | Out-Null
        }
    }
} # end function Invoke-TermsrvPatch

# =====================================================
#  HANDLE -PATCHONLY SWITCH
# =====================================================
if ($PatchOnly) {
    # Elevate if not admin (for manual run)
    if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        Write-Host "Elevating to Administrator for patch..." -ForegroundColor Yellow
        Start-Process PowerShell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -PatchOnly" -Verb RunAs
        exit
    }
    Invoke-TermsrvPatch
    exit 0
}

# =====================================================
#  MAIN SCRIPT (RUN ONCE)
# =====================================================

# Set execution policy for current process
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Elevating to Administrator..." -ForegroundColor Yellow
    Start-Process PowerShell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

function Exit-WithError {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# ---- Copy script and EasyTier folder ----
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$targetDir = $TargetBaseDir

if (-not (Test-Path $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    Write-Host "Created folder: $targetDir" -ForegroundColor Cyan
}

$currentScript = $MyInvocation.MyCommand.Path
$targetScript = Join-Path $targetDir "RDPSetup.ps1"
Copy-Item -Path $currentScript -Destination $targetScript -Force
Write-Host "Script copied from $currentScript to $targetScript" -ForegroundColor Green

$sourceEasyTier = Join-Path $scriptDir "EasyTier"
if (Test-Path $sourceEasyTier) {
    $targetEasyTier = Join-Path $targetDir "EasyTier"
    if (Test-Path $targetEasyTier) {
        Remove-Item -Path $targetEasyTier -Recurse -Force -ErrorAction SilentlyContinue
    }
    Copy-Item -Path $sourceEasyTier -Destination $targetEasyTier -Recurse -Force
    Write-Host "EasyTier folder copied from $sourceEasyTier to $targetEasyTier" -ForegroundColor Green
} else {
    Write-Host "WARNING: EasyTier folder not found next to script, skipping." -ForegroundColor Yellow
}

# ---- Create scheduled task ----
$xmlContent = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Automatically patch termsrv.dll at boot for re-enabling concurrent remote desktop connections after Windows updates</Description>
    <URI>\TermsrvPatcher</URI>
  </RegistrationInfo>
  <Triggers>
    <BootTrigger>
      <Enabled>true</Enabled>
      <Delay>PT30S</Delay>
    </BootTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>SYSTEM</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <Duration>PT10M</Duration>
      <WaitTimeout>PT1H</WaitTimeout>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
    <Priority>7</Priority>
    <RestartOnFailure>
      <Interval>PT5M</Interval>
      <Count>10</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe</Command>
      <Arguments>-NoProfile -ExecutionPolicy Bypass -File "$targetScript" -PatchOnly</Arguments>
    </Exec>
  </Actions>
</Task>
"@

$tempXml = Join-Path $env:TEMP "TermsrvPatcher.xml"
$xmlContent | Out-File -FilePath $tempXml -Encoding Unicode
Write-Host "Temporary XML created: $tempXml" -ForegroundColor Cyan

$taskName = "TermsrvPatcher"
try {
    schtasks /delete /tn $taskName /f 2>$null
    schtasks /create /xml $tempXml /tn $taskName /f
    Write-Host "Task '$taskName' successfully created." -ForegroundColor Green
}
catch {
    Write-Host "Error creating task: $_" -ForegroundColor Red
}
finally {
    if (Test-Path $tempXml) { Remove-Item $tempXml -Force }
}

# ---- Create user and enable RDP ----
Write-Host ""
Write-Host "====================================================="
Write-Host " Creating user and configuring Remote Desktop"
Write-Host "====================================================="

$SecurePassword = ConvertTo-SecureString $PasswordPlain -AsPlainText -Force

Write-Host "[1/5] Creating/updating user $Username..."
try {
    $existingUser = Get-LocalUser -Name $Username -ErrorAction SilentlyContinue
    if ($existingUser) {
        Write-Host "User '$Username' already exists. Updating password..." -ForegroundColor Yellow
        Set-LocalUser -Name $Username -Password $SecurePassword -PasswordNeverExpires $true
    } else {
        New-LocalUser -Name $Username -Password $SecurePassword -FullName $Username -Description "Remote access user" -PasswordNeverExpires -ErrorAction Stop | Out-Null
        Write-Host "User created successfully." -ForegroundColor Green
    }
}
catch {
    Exit-WithError "ERROR creating/updating user: $_"
}

Write-Host "[2/5] Setting non-expiring password..."
Set-LocalUser -Name $Username -PasswordNeverExpires $true -ErrorAction SilentlyContinue
Write-Host "Password never expires." -ForegroundColor Green

Write-Host "[3/5] Adding user to Remote Desktop Users group..."
$groupRdp = Get-LocalGroup -SID "S-1-5-32-555" -ErrorAction SilentlyContinue
if ($groupRdp) {
    Add-LocalGroupMember -Group $groupRdp -Member $Username -ErrorAction SilentlyContinue
    Write-Host "Added to Remote Desktop Users." -ForegroundColor Green
} else {
    Write-Host "WARNING: Remote Desktop Users group not found (SID S-1-5-32-555)" -ForegroundColor Yellow
}

Write-Host "[4/5] Adding user to Administrators group..."
$groupAdmin = Get-LocalGroup -SID "S-1-5-32-544" -ErrorAction SilentlyContinue
if ($groupAdmin) {
    Add-LocalGroupMember -Group $groupAdmin -Member $Username -ErrorAction SilentlyContinue
    Write-Host "Added to Administrators." -ForegroundColor Green
} else {
    Write-Host "WARNING: Administrators group not found (SID S-1-5-32-544)" -ForegroundColor Yellow
}

Write-Host "[5/5] Enabling Remote Desktop and opening port 3389..."
try {
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections" -Value 0 -Type DWord -ErrorAction Stop
    Write-Host "Remote Desktop enabled in registry." -ForegroundColor Green
}
catch {
    Write-Host "ERROR enabling RDP in registry: $_" -ForegroundColor Red
}

$ruleName = "Remote Desktop (TCP 3389)"
try {
    if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
    }
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3389 -ErrorAction Stop | Out-Null
    Write-Host "Firewall rule created (port 3389 open)." -ForegroundColor Green
}
catch {
    Write-Host "WARNING: Could not create firewall rule: $_" -ForegroundColor Yellow
}

# ---- Install VPN service (no network parameters, not started) ----
$serviceBinary = Join-Path $TargetBaseDir "EasyTier\easytier-core.exe"

# Stop and remove existing service if present
$existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existingService) {
    Write-Host "Service '$ServiceName' already exists. Stopping and removing..." -ForegroundColor Yellow
    try {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        sc.exe delete $ServiceName
        Start-Sleep -Seconds 2
    }
    catch {
        Write-Host "Failed to remove service: $_" -ForegroundColor Red
    }
}

if (Test-Path $serviceBinary) {
    # Service is created with ONLY the binary path.
    # Network parameters are supplied later by connect_*.bat via "sc config ... binPath= ..."
    $binaryPath = "`"$serviceBinary`""
    try {
        New-Service -Name $ServiceName `
                    -BinaryPathName $binaryPath `
                    -DisplayName $ServiceDisplayName `
                    -StartupType Automatic | Out-Null
        Write-Host "VPN service ($ServiceName) installed (network parameters NOT set)." -ForegroundColor Green
    }
    catch {
        Write-Host "ERROR creating service: $_" -ForegroundColor Red
    }
} else {
    Write-Host "WARNING: easytier-core.exe not found, service not installed." -ForegroundColor Yellow
}

# ---- Reboot ----
Write-Host ""
Write-Host "====================================================="
Write-Host " Done! User '$Username' configured."
Write-Host " Password: $PasswordPlain"
Write-Host " Password never expires."
Write-Host " Remote Desktop enabled (port 3389 open)."
Write-Host " VPN service installed (not started, no network parameters)."
Write-Host " Use connect_*.bat to set network parameters and start the service."
Write-Host " Script will run automatically at every boot."
Write-Host "====================================================="

Write-Host "Computer will reboot in 1 second to apply changes..."
Start-Sleep -Seconds 1
Restart-Computer -Force